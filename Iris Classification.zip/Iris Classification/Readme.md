# Iris Classification with Random Forest

## Project Overview
This project demonstrates how to classify Iris species using a Random Forest classifier. The dataset used is the Iris dataset, which contains four features about Iris flowers (sepal length, sepal width, petal length, petal width) and their corresponding species. 

The model is evaluated using cross-validation and classification metrics such as accuracy, precision, recall, and F1-score.

## Steps Taken:
1. **Data Preprocessing**: Loaded the Iris dataset, separated features and target labels, and performed data splitting.
2. **Model Training**: Trained a Random Forest classifier.
3. **Evaluation**: Evaluated the model using cross-validation and performance metrics (confusion matrix, classification report).
4. **Visualizations**: Visualized the feature importance and confusion matrix.

## How to Run
1. Clone the repository:
   ```bash
   git clone https://github.com/your-username/Iris_Classification.git
   
2. Navigate into the project directory:
    ```bash
    cd Iris_Classification
3.Install the required libraries:
    ```bash
    pip install -r requirements.txt
4. Open the Jupyter notebook (Iris_Classification.ipynb) and run all cells:
bash
Copy code
